package com.example.sensormobileapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
